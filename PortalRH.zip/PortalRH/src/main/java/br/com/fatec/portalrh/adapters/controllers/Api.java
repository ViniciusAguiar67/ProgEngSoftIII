package br.com.fatec.portalrh.adapters.controllers;

public class Api {
    public static final String EXECUTE = "execute";
    public static final String CONTROLLERS_EXECUTE = "br.com.fatec.portalrh.adapters.controllers.execute.";
    public static final String WEB_INF_VIEW = "WEB-INF/view/";
    public static final String LOGIN_JSP = "forward:formLogin.jsp";
    public static final String LISTA_FUNCIONARIOS_JSP = "forward:listaFuncionarios.jsp";
    public static final String REDIRECT_LISTA_FUNCIONARIOS = "redirect:entrada?execute=ListaFuncionarios";
    public static final String REDIRECT_LOGIN_FORM = "redirect:entrada?execute=LoginForm";
    public static final String FORWARD_ALTERA_FUNCIONARIO_JSP = "forward:formAlteraFuncionario.jsp";
    public static final String FORWARD_NOVO_FUNCIONARIO_JSP = "forward:formNovoFuncionario.jsp";
}

package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.entities.valueObject.endereco.Cidade;
import br.com.fatec.portalrh.entities.valueObject.endereco.Endereco;
import br.com.fatec.portalrh.entities.valueObject.endereco.Estado;
import br.com.fatec.portalrh.entities.enums.Genero;
import br.com.fatec.portalrh.entities.valueObject.Cpf;
import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.Command;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static br.com.fatec.portalrh.adapters.controllers.Api.REDIRECT_LISTA_FUNCIONARIOS;
import static br.com.fatec.portalrh.adapters.controllers.util.FuncionarioDados.*;


public class AlteraFuncionario implements Command {

    private static final SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();

    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        Funcionario funcionario = new Funcionario();
        String nomeFuncionario = request.getParameter(NOME_FUNCIONARIO);
        String cpfFuncionario = request.getParameter(CPF_FUNCIONARIO);
        String dataFuncionario = request.getParameter(DATA_FUNCIONARIO);
        String salario = request.getParameter(SALARIO_FUNCIONARIO);
        String logradouro = request.getParameter(LOGRADOURO);
        String numero = request.getParameter(NUMERO);
        String cep = request.getParameter(CEP);
        String bairro = request.getParameter(BAIRRO);
        String cidade = request.getParameter(CIDADE);
        String estado = request.getParameter(ESTADO);
        String departamentoid = request.getParameter(DEPARTAMENTO);
        String generoFuncionario = request.getParameter(GENERO_FUNCIONARIO);
        String regime = request.getParameter(REGIME_FUNCIONARIO);

        String paramId = request.getParameter(ID);
        Long id = Long.valueOf(paramId);
        //-----------------------------------------------------------------------
        Funcionario funcionarioOriginal = new Funcionario();
        try {
            funcionarioOriginal = sistemaRhUseCase.buscarFuncionarioPorId(id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        DataNascimento dataNascimento = null;
        if (dataFuncionario.isEmpty()) {
            try {
                dataNascimento = funcionarioOriginal.getDataNascimento();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            try {
                dataNascimento = new DataNascimento(dataFuncionario);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        if (departamentoid.equals("...")) {
            departamentoid = funcionarioOriginal.getDepartamento().getId().toString();
        }

        if (generoFuncionario.equals("...")) {
            generoFuncionario = funcionarioOriginal.getGenero().toString();
        }

        if (regime.equals("...")) {
            regime = funcionarioOriginal.getRegime();
        }

        //-----------------------------------------------------------------------
        System.out.println("execute: altera funcionario " + id);

        try {
            funcionario = new Funcionario(
                    null,
                    BigDecimal.valueOf(Double.parseDouble(salario)),
                    nomeFuncionario,
                    new Cpf(cpfFuncionario),
                    dataNascimento,
                    new Endereco(logradouro,
                            numero,
                            cep,
                            bairro,
                            Arrays.asList(new Estado(estado,
                                    new Cidade(cidade)))),
                    new Departamento(Long.valueOf(departamentoid)),
                    null,
                    Genero.valueOf(generoFuncionario),
                    regime);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        try {
            sistemaRhUseCase.atualizarDadosFuncionario(funcionario, id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return REDIRECT_LISTA_FUNCIONARIOS;
    }
}

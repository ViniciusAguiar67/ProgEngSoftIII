package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.Command;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import static br.com.fatec.portalrh.adapters.controllers.Api.LISTA_FUNCIONARIOS_JSP;

public class ListaFuncionarios implements Command {

    private static final SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();


    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        System.out.println("listando Funcionários");

        List<Funcionario> funcionarioList = null;
        try {
            funcionarioList = sistemaRhUseCase.buscarTodosFuncionarios();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        request.setAttribute("funcionarios", funcionarioList);

        return LISTA_FUNCIONARIOS_JSP;
    }
}

package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.adapters.db.accessUser.SimulationBank;
import br.com.fatec.portalrh.entities.users.Usuario;
import br.com.fatec.portalrh.ports.userInterface.Command;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static br.com.fatec.portalrh.adapters.controllers.Api.*;

public class Login implements Command {

    private static final String LOGIN = "login";
    private static final String SENHA = "senha";

    @Override
    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        String login = request.getParameter(LOGIN);
        String senha = request.getParameter(SENHA);
        String mensagem = null;

        System.out.println("Logando " + login);

        SimulationBank simulationBank = new SimulationBank();
        Usuario usuario = simulationBank.existeUsuario(login, senha);


        if (usuario != null) {
            System.out.println("Usuario existe");
            HttpSession sessao = request.getSession();
            sessao.setAttribute("usuarioLogado", usuario);
            return REDIRECT_LISTA_FUNCIONARIOS;
        } else {
            return REDIRECT_LOGIN_FORM;
        }
    }
}

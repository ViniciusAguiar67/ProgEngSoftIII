package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.ports.userInterface.Command;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static br.com.fatec.portalrh.adapters.controllers.Api.LOGIN_JSP;

//@WebServlet(name = "formLogin", value = "/form-login")
public class LoginForm implements Command {

    @Override
    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        System.out.println("Exibindo tela Login");

        return LOGIN_JSP;
    }
}

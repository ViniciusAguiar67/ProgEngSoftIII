package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.ports.userInterface.Command;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static br.com.fatec.portalrh.adapters.controllers.Api.REDIRECT_LOGIN_FORM;

public class Logout implements Command {

    @Override
    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        HttpSession sessao = request.getSession();
        sessao.invalidate();

        System.out.println("Logout");

        return REDIRECT_LOGIN_FORM;
    }
}

package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.Command;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static br.com.fatec.portalrh.adapters.controllers.Api.FORWARD_ALTERA_FUNCIONARIO_JSP;

public class MostraFuncionario implements Command {

    private static final SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();
    private static final String ID = "id";
    private static final String DEPARTAMENTOS = "departamentos";
    private static final String FUNCIONARIO = "funcionario";


    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        Funcionario funcionario = new Funcionario();
        System.out.println("mostrando dados do funcionario");

        String paramId = request.getParameter(ID);
        Long id = Long.valueOf(paramId);

        try {
            funcionario = sistemaRhUseCase.buscarFuncionarioPorId(id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        List<Departamento> departamentos = null;
        try {
            departamentos = sistemaRhUseCase.listarDepartamento();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        request.setAttribute(DEPARTAMENTOS, departamentos);

        System.out.println(funcionario.getNome());

        request.setAttribute(FUNCIONARIO, funcionario);

        return FORWARD_ALTERA_FUNCIONARIO_JSP;
    }
}

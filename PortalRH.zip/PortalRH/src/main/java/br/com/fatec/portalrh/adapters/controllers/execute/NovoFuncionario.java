package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Dependente;
import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.entities.valueObject.endereco.Cidade;
import br.com.fatec.portalrh.entities.valueObject.endereco.Endereco;
import br.com.fatec.portalrh.entities.valueObject.endereco.Estado;
import br.com.fatec.portalrh.entities.enums.Genero;
import br.com.fatec.portalrh.entities.enums.Parentesco;
import br.com.fatec.portalrh.entities.valueObject.Cpf;
import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.Command;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static br.com.fatec.portalrh.adapters.controllers.Api.REDIRECT_LISTA_FUNCIONARIOS;
import static br.com.fatec.portalrh.adapters.controllers.util.FuncionarioDados.*;

public class NovoFuncionario implements Command {

    private static final SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();
    private static final String NOME_DEPENDENTE = "nomeDependente";
    private static final String CPF_DEPENDENTE = "cpfDependente";
    private static final String DATA_DEPENDENTE = "dataDependente";
    private static final String GENERO_DEPENDENTE = "generoDependente";
    private static final String PARENTESCO_DEPENDENTE = "parentescoDependente";
    private static final String FUNCIONARIO = "funcionario";
    private static final String CLT = "Clt";

    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        System.out.println("Cadastrando novo Funcionario");

        Funcionario funcionario = new Funcionario();
        String nomeFuncionario = request.getParameter(NOME_FUNCIONARIO);
        String cpfFuncionario = request.getParameter(CPF_FUNCIONARIO);
        String dataFuncionario = request.getParameter(DATA_FUNCIONARIO);
        String salario = request.getParameter(SALARIO_FUNCIONARIO);
        String logradouro = request.getParameter(LOGRADOURO);
        String numero = request.getParameter(NUMERO);
        String cep = request.getParameter(CEP);
        String bairro = request.getParameter(BAIRRO);
        String cidade = request.getParameter(CIDADE);
        String estado = request.getParameter(ESTADO);
        String departamentoid = request.getParameter(DEPARTAMENTO);
        String generoFuncionario = request.getParameter(GENERO_FUNCIONARIO);
        String regime = request.getParameter(REGIME_FUNCIONARIO);

        String nomeDependente = request.getParameter(NOME_DEPENDENTE);
        String cpfDependente = request.getParameter(CPF_DEPENDENTE);
        String dataDependente = request.getParameter(DATA_DEPENDENTE);
        String generoDependente = request.getParameter(GENERO_DEPENDENTE);
        String parentesco = request.getParameter(PARENTESCO_DEPENDENTE);

        Map<Long, Dependente> dependenteMap = new HashMap<>();
        Dependente dependente = null;

        if (regime.equals("...")) {
            regime = CLT;
        }

        if (!(nomeDependente.isEmpty())) {
            try {
                dependente = new Dependente(null,
                        nomeDependente,
                        new Cpf(cpfDependente),
                        new DataNascimento(dataDependente),
                        Genero.valueOf(generoDependente),
                        Parentesco.valueOf(parentesco),
                        null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            dependenteMap.put(1L, dependente);
        }

        try {
            funcionario = new Funcionario(
                    null,
                    BigDecimal.valueOf(Double.parseDouble(salario)),
                    nomeFuncionario,
                    new Cpf(cpfFuncionario),
                    new DataNascimento(dataFuncionario),
                    new Endereco(logradouro,
                            numero,
                            cep,
                            bairro,
                            Arrays.asList(new Estado(estado,
                                    new Cidade(cidade)))),
                    new Departamento(Long.valueOf(departamentoid)),
                    dependenteMap,
                    Genero.valueOf(generoFuncionario),
                    regime);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        sistemaRhUseCase.salvarFuncionario(funcionario, regime);

        request.setAttribute(FUNCIONARIO, funcionario.getNome());

        return REDIRECT_LISTA_FUNCIONARIOS;
    }
}

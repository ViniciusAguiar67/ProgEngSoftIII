package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.Command;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static br.com.fatec.portalrh.adapters.controllers.Api.FORWARD_NOVO_FUNCIONARIO_JSP;

public class NovoFuncionarioForm implements Command {
    private static final SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();

    private static final String DEPARTAMENTOS = "departamentos";

    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        List<Departamento> departamentos = null;
        try {
            departamentos = sistemaRhUseCase.listarDepartamento();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        request.setAttribute(DEPARTAMENTOS, departamentos);

        System.out.println("Chamando Funcionario Form");

        return FORWARD_NOVO_FUNCIONARIO_JSP;
    }
}

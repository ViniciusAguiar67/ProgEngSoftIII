package br.com.fatec.portalrh.adapters.controllers.execute;

import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.Command;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static br.com.fatec.portalrh.adapters.controllers.Api.REDIRECT_LISTA_FUNCIONARIOS;

public class RemoveFuncionario implements Command {

    private static final SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();
    private static final String ID = "id";

    public String execute(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        System.out.println("execute: removendo funcionario");

        String paramId = request.getParameter(ID);
        Long id = Long.valueOf(paramId);

        System.out.println(id);

        try {
            sistemaRhUseCase.excluirFuncionario(id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return REDIRECT_LISTA_FUNCIONARIOS;
    }
}

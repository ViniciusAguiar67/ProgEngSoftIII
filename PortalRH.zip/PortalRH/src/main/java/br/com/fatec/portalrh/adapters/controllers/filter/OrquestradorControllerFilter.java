package br.com.fatec.portalrh.adapters.controllers.filter;

import br.com.fatec.portalrh.adapters.controllers.servlet.OrquestradorController;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

//@WebFilter("/entrada")
public class OrquestradorControllerFilter implements Filter {

    public void doFilter(ServletRequest servletRequest,
                         ServletResponse servletResponse,
                         FilterChain chain
    ) throws IOException, ServletException {

        System.out.println("OrquestradorControllerFilter");
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        OrquestradorController.paramAcao(request, response);
    }
}

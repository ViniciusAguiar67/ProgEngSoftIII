package br.com.fatec.portalrh.adapters.controllers.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;
import com.google.gson.Gson;
import com.thoughtworks.xstream.XStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/funcionarios")
public class FuncionarioService extends HttpServlet {
    private static final long serialVersionUID = 1L;
    public static final SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();

    protected void service(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {
        List<Funcionario> funcionarios = new ArrayList<>();

        try {
            funcionarios = sistemaRhUseCase.buscarTodosFuncionarios();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        String valor = request.getHeader("Accept");

        System.out.println(valor);

        if (valor.contains("xml")) {
            XStream xstream = new XStream();
            xstream.alias("funcionario", Funcionario.class);
            String xml = xstream.toXML(funcionarios);

            response.setContentType("application/xml");
            response.getWriter().print(xml);
        } else if (valor.endsWith("json")) {
            Gson gson = new Gson();
            String json = gson.toJson(funcionarios);

            response.setContentType("application/json");
            response.getWriter().print(json);
        } else {
            response.setContentType("application/json");
            response.getWriter().print("{'message':'no content'}");
        }
    }
}









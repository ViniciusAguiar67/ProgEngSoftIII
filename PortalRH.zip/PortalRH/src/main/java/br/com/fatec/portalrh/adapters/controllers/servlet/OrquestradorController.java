package br.com.fatec.portalrh.adapters.controllers.servlet;

import br.com.fatec.portalrh.ports.userInterface.Command;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static br.com.fatec.portalrh.adapters.controllers.Api.*;

//@WebServlet(urlPatterns="/entrada")
public class OrquestradorController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    public static final String FORWARD = "forward";

    protected void service(
            HttpServletRequest request,
            HttpServletResponse response
    ) throws ServletException, IOException {

        paramAcao(request, response);
    }

    public static void paramAcao(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String paramAcao = request.getParameter(EXECUTE);

        System.out.println("chamando orquestrador");
        String nomeDaClasse = CONTROLLERS_EXECUTE + paramAcao;

        String nome;
        try {
            Class classe = Class.forName(nomeDaClasse);
            Command command = (Command) classe.newInstance();
            nome = command.execute(request, response);
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            throw new ServletException(e);
        }

        String[] tipoEEndereco = nome.split(":");
        if (tipoEEndereco[0].equals(FORWARD)) {
            RequestDispatcher rd = request.getRequestDispatcher(WEB_INF_VIEW + tipoEEndereco[1]);
            rd.forward(request, response);
        } else {
            response.sendRedirect(tipoEEndereco[1]);
        }
    }
}

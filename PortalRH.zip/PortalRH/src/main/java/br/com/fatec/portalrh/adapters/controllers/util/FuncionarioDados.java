package br.com.fatec.portalrh.adapters.controllers.util;

public class FuncionarioDados {
    public static final String ID = "id";
    public static final String NOME_FUNCIONARIO = "nomeFuncionario";
    public static final String CPF_FUNCIONARIO = "cpfFuncionario";
    public static final String DATA_FUNCIONARIO = "dataFuncionario";
    public static final String SALARIO_FUNCIONARIO = "salarioFuncionario";
    public static final String LOGRADOURO = "logradouro";
    public static final String NUMERO = "numero";
    public static final String CEP = "cep";
    public static final String BAIRRO = "bairro";
    public static final String CIDADE = "cidade";
    public static final String ESTADO = "estado";
    public static final String DEPARTAMENTO = "departamento";
    public static final String GENERO_FUNCIONARIO = "generoFuncionario";
    public static final String REGIME_FUNCIONARIO = "regimeFuncionario";
}
package br.com.fatec.portalrh.adapters.db.accessUser;

import br.com.fatec.portalrh.entities.users.Usuario;

import java.util.ArrayList;
import java.util.List;


public class SimulationBank {

    private static List<Usuario> listaUsuarios = new ArrayList<>();

    static {

        Usuario u1 = new Usuario();
        u1.setLogin("admin");
        u1.setSenha("12345");

        listaUsuarios.add(u1);
    }

    public Usuario existeUsuario(String login, String senha) {
        for (Usuario usuario : listaUsuarios) {
            if (usuario.ehIgual(login, senha)) {
                return usuario;
            }
        }
        return null;
    }
}

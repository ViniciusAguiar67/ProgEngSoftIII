package br.com.fatec.portalrh.adapters.jdbc.impl;


import br.com.fatec.portalrh.adapters.db.Db;
import br.com.fatec.portalrh.ports.infrastructure.FuncionarioDao;

public class DaoFactory {

    public static FuncionarioDao createFuncionarioDao(){
        return new FuncionarioDaoJdbc(Db.getConnection());
    }
}

package br.com.fatec.portalrh.adapters.jdbc.impl;


import br.com.fatec.portalrh.adapters.db.Db;
import br.com.fatec.portalrh.adapters.db.DbException;
import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Dependente;
import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.entities.Projeto;
import br.com.fatec.portalrh.entities.valueObject.endereco.Cidade;
import br.com.fatec.portalrh.entities.valueObject.endereco.Endereco;
import br.com.fatec.portalrh.entities.valueObject.endereco.Estado;
import br.com.fatec.portalrh.entities.enums.Genero;
import br.com.fatec.portalrh.entities.enums.Parentesco;
import br.com.fatec.portalrh.entities.valueObject.Cpf;
import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import br.com.fatec.portalrh.ports.infrastructure.FuncionarioDao;

import java.sql.*;
import java.util.*;

public class FuncionarioDaoJdbc implements FuncionarioDao {

    private Connection conn;

    public FuncionarioDaoJdbc(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void insert(Funcionario funcionario) {
        insertFuncionario(funcionario);
        Long funcionarioId = funcionario.getId();

        if (!funcionario.getDependentes().isEmpty()){
            insertDependente(funcionario, funcionarioId);
        }
    }

    @Override
    public void update(Funcionario funcionario) {
        PreparedStatement st = null;

        updateFuncionario(funcionario, st);
    }

    @Override
    public Funcionario delete(Long id) {
        PreparedStatement st = null;
        ResultSet rs = null;
        return deleteDadosFuncionarios(id, st, rs);
    }

    @Override
    public Optional<Funcionario> findById(Long id) throws Exception {
        PreparedStatement st = null;
        ResultSet rs = null;
        if (findDadosId(id, st, rs) == null) {
            return null;
        }
        Funcionario dadosId = findDadosId(id, st, rs);

        return Optional.ofNullable(dadosId);
    }

    @Override
    public List<Funcionario> findAll() throws Exception {
        PreparedStatement st = null;
        ResultSet rs = null;

        return findDadosFuncionario(st, rs);
    }

    @Override
    public List<Departamento> findAllDepartamento() {
        PreparedStatement st = null;
        ResultSet rs = null;

        try {
            st = conn.prepareStatement("SELECT * FROM `departamento`");
            rs = st.executeQuery();

            List<Departamento> listaDepartamento = new ArrayList<>();
            while (rs.next()) {
                Departamento departamento = new Departamento();
                departamento.setId(rs.getLong("dep_id"));
                try {
                    departamento.setNome(rs.getString("dep_nome"));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                listaDepartamento.add(departamento);
            }
            return listaDepartamento;
        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            Db.closeStatement(st);
            Db.closeResultSet(rs);
        }
    }

    private Funcionario deleteDadosFuncionarios(Long id, PreparedStatement st, ResultSet rs) {
        try {
            st = conn.prepareStatement("DELETE FROM `funcionario` WHERE fun_id = ?");
            st.setLong(1, id);
            st.executeUpdate();

        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            Db.closeStatement(st);
            Db.closeResultSet(rs);
        }
        return null;
    }

    private Funcionario findDadosId(Long id, PreparedStatement st, ResultSet rs) throws Exception {
        try {

            st = conn.prepareStatement("SELECT * FROM `funcionario` LEFT OUTER JOIN " +
                    "dependente ON dependente.dpt_fun_id = fun_id INNER JOIN " +
                    "departamento ON funcionario.fun_dep_id = dep_id LEFT OUTER JOIN " +
                    "projeto ON projeto.prj_dep_id = departamento.dep_id " +
                    " WHERE fun_id = ?");
            st.setLong(1, id);

            rs = st.executeQuery();

            Funcionario funcionario = new Funcionario();
            Map<Long, Dependente> mapDependente = new HashMap<>();
            if (rs.next()) {
                funcionario.setId(rs.getLong("fun_id"));
                funcionario.setNome(rs.getString("fun_cnome"));
                funcionario.setCpf(new Cpf(rs.getString("fun_cpf")));
                funcionario.setDataNascimento(new DataNascimento(rs.getString("fun_dataNascimento")));
                funcionario.setSalario(rs.getBigDecimal("fun_salario"));
                funcionario.setRegime(rs.getString("fun_regime"));
                funcionario.setGenero(Genero.valueOf(rs.getString("fun_genero")));

                funcionario.setEndereco(new Endereco(
                        rs.getString("fun_logradouro"),
                        rs.getString("fun_logradouroNumero"),
                        rs.getString("fun_logradouroCep"),
                        rs.getString("fun_logradouroBairro"),
                        Arrays.asList(
                                new Estado(rs.getString("fun_logradouroEstado"),
                                        new Cidade(rs.getString("fun_logradouroCidade"))))));

                Dependente dependente = mapDependente.get(rs.getLong("dpt_id"));
                if (dependente == null) {
                    Long funcionarioExiste = rs.getLong("dpt_fun_id");
                    if (funcionarioExiste > 0) {
                        Dependente dependente1 = new Dependente();
                        dependente1.setId(rs.getLong("dpt_id"));
                        dependente1.setNome(rs.getString("dpt_cnome"));
                        dependente1.setCpf(new Cpf(rs.getString("dpt_cpf")));
                        dependente1.setDataNascimento(new DataNascimento(rs.getString("dpt_dataNascimento")));
                        dependente1.setGenero(Genero.valueOf(rs.getString("dpt_genero")));
                        dependente1.setParentesco(Parentesco.valueOf(rs.getString("dpt_parentesco")));

                        if (Objects.equals(funcionarioExiste, funcionario.getId())) {
                            mapDependente.put(rs.getLong("dpt_id"), dependente1);
                            funcionario.setDependentes(mapDependente);
                        }
                    }
                }
                funcionario.setDepartamento(new Departamento(rs.getLong("fun_dep_id"),
                        rs.getString("dep_nome"),
                        Arrays.asList(new Projeto(rs.getLong("prj_id"),
                                rs.getString("prj_cnome"),
                                rs.getString("prj_local")))));
                return funcionario;
            }
            return null;
        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            Db.closeStatement(st);
            Db.closeResultSet(rs);
        }
    }

    private List<Funcionario> findDadosFuncionario(PreparedStatement st, ResultSet rs) throws Exception {
        try {

            st = conn.prepareStatement("SELECT * FROM `funcionario` LEFT OUTER JOIN " +
                    "dependente ON dependente.dpt_fun_id = fun_id INNER JOIN " +
                    "departamento ON funcionario.fun_dep_id = dep_id LEFT OUTER JOIN " +
                    "projeto ON projeto.prj_dep_id = departamento.dep_id");
            rs = st.executeQuery();

            List<Funcionario> listaFuncionarios = new ArrayList<>();
            while (rs.next()) {
                Map<Long, Dependente> mapDependente = new HashMap<>();
                Funcionario funcionario = new Funcionario();
                funcionario.setId(rs.getLong("fun_id"));
                funcionario.setNome(rs.getString("fun_cnome"));
                funcionario.setCpf(new Cpf(rs.getString("fun_cpf")));
                funcionario.setDataNascimento(new DataNascimento(rs.getString("fun_dataNascimento")));
                funcionario.setSalario(rs.getBigDecimal("fun_salario"));
                funcionario.setRegime(rs.getString("fun_regime"));
                funcionario.setGenero(Genero.valueOf(rs.getString("fun_genero")));

                funcionario.setEndereco(new Endereco(
                        rs.getString("fun_logradouro"),
                        rs.getString("fun_logradouroNumero"),
                        rs.getString("fun_logradouroCep"),
                        rs.getString("fun_logradouroBairro"),
                        Arrays.asList(
                                new Estado(rs.getString("fun_logradouroEstado"),
                                        new Cidade(rs.getString("fun_logradouroCidade"))))));

                Dependente dependente = mapDependente.get(rs.getLong("dpt_id"));
                if (dependente == null) {
                    Long funcionarioExiste = rs.getLong("dpt_fun_id");
                    if (funcionarioExiste > 0) {
                        Dependente dependente1 = new Dependente();
                        dependente1.setId(rs.getLong("dpt_id"));
                        dependente1.setNome(rs.getString("dpt_cnome"));
                        dependente1.setCpf(new Cpf(rs.getString("dpt_cpf")));
                        dependente1.setDataNascimento(new DataNascimento(rs.getString("dpt_dataNascimento")));
                        dependente1.setGenero(Genero.valueOf(rs.getString("dpt_genero")));
                        dependente1.setParentesco(Parentesco.valueOf(rs.getString("dpt_parentesco")));

                        if (Objects.equals(funcionarioExiste, funcionario.getId())) {
                            mapDependente.put(rs.getLong("dpt_id"), dependente1);
                            funcionario.setDependentes(mapDependente);
                        }
                    }
                }
                funcionario.setDepartamento(new Departamento(rs.getLong("fun_dep_id"),
                        rs.getString("dep_nome"),
                        Arrays.asList(new Projeto(rs.getLong("prj_id"),
                                rs.getString("prj_cnome"),
                                rs.getString("prj_local")))));

                listaFuncionarios.add(funcionario);
            }
            return listaFuncionarios;
        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            Db.closeStatement(st);
            Db.closeResultSet(rs);
        }
    }

    private void insertFuncionario(Funcionario funcionario) {
        PreparedStatement st = null;
        try {
            st = conn.prepareStatement("INSERT INTO `funcionario`" +
                    "(`fun_cnome`, `fun_cpf`, `fun_dataNascimento`, `fun_salario`, " +
                    "`fun_regime`, `fun_genero`, `fun_logradouro`, `fun_logradouroNumero`, " +
                    "`fun_logradouroBairro`, `fun_logradouroCidade`, `fun_logradouroEstado`, " +
                    "`fun_logradouroCep`, `fun_dep_id`) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);

            st.setString(1, funcionario.getNome());
            st.setString(2, funcionario.getCpf().getCpf());
            st.setDate(3, new java.sql.Date(funcionario.getDataNascimento().getDataNascimento().getTime()));
            st.setDouble(4, funcionario.getSalario().doubleValue());
            st.setString(5, funcionario.getRegime());
            st.setString(6, funcionario.getGenero().name());
            st.setString(7, funcionario.getEndereco().getLogradouro());
            st.setString(8, funcionario.getEndereco().getNumero());
            st.setString(9, funcionario.getEndereco().getBairro());
            st.setString(10, funcionario.getEndereco().getEstados().get(0).getCidade().getNome());
            st.setString(11, funcionario.getEndereco().getEstados().get(0).getNome());
            st.setString(12, funcionario.getEndereco().getCep());
            st.setLong(13, funcionario.getDepartamento().getId());
            int rowsAffected = st.executeUpdate();
            if (rowsAffected > 0) {
                ResultSet rs = st.getGeneratedKeys();
                if (rs.next()) {
                    int id = rs.getInt(1);
                    String idString = String.valueOf(id);
                    funcionario.setId(Long.parseLong(idString));
                }
                Db.closeResultSet(rs);
            }

        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            Db.closeStatement(st);
        }
    }


    private void insertDependente(Funcionario funcionario, Long funcionarioId) {
        PreparedStatement st = null;

        try {
            st = conn.prepareStatement("INSERT INTO `dependente`" +
                    "(`dpt_cnome`, `dpt_cpf`, `dpt_dataNascimento`, " +
                    "`dpt_genero`, `dpt_parentesco`, `dpt_fun_id`) " +
                    "VALUES (?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);

            st.setString(1, funcionario.getDependentes().get(1L).getNome());
            st.setString(2, funcionario.getDependentes().get(1L).getCpf().getCpf());
            st.setDate(3, new java.sql.Date(funcionario.getDependentes().get(1L).getDataNascimento().getDataNascimento().getTime()));
            st.setString(4, funcionario.getDependentes().get(1L).getGenero().name());
            st.setString(5, funcionario.getDependentes().get(1L).getParentesco().name());
            st.setLong(6, funcionarioId);
            int rowsAffected = st.executeUpdate();
            if (rowsAffected > 0) {
                ResultSet rs = st.getGeneratedKeys();
                if (rs.next()) {
                    int id = rs.getInt(1);
                    String idString = String.valueOf(id);
                    funcionario.getDependentes().get(1L).setId(Long.parseLong(idString));
                }
                Db.closeResultSet(rs);
            }

        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            Db.closeStatement(st);
        }
    }

    private void updateFuncionario(Funcionario funcionario, PreparedStatement st) {
        try {
            st = conn.prepareStatement("UPDATE `funcionario` SET " +
                    "`fun_cnome` = ?, `fun_cpf` = ?, `fun_dataNascimento` = ?, `fun_salario` = ?, " +
                    "`fun_regime` = ?, `fun_genero` = ?, `fun_logradouro` = ?, `fun_logradouroNumero` = ?, " +
                    "`fun_logradouroBairro` = ?, `fun_logradouroCidade` = ?, `fun_logradouroEstado` = ?, " +
                    "`fun_logradouroCep` = ?, `fun_dep_id` = ? WHERE fun_id = ?");

            st.setString(1, funcionario.getNome());
            st.setString(2, funcionario.getCpf().getCpf());
            st.setDate(3, new java.sql.Date(funcionario.getDataNascimento().getDataNascimento().getTime()));
            st.setDouble(4, funcionario.getSalario().doubleValue());
            st.setString(5, funcionario.getRegime());
            st.setString(6, funcionario.getGenero().name());
            st.setString(7, funcionario.getEndereco().getLogradouro());
            st.setString(8, funcionario.getEndereco().getNumero());
            st.setString(9, funcionario.getEndereco().getBairro());
            st.setString(10, funcionario.getEndereco().getEstados().get(0).getCidade().getNome());
            st.setString(11, funcionario.getEndereco().getEstados().get(0).getNome());
            st.setString(12, funcionario.getEndereco().getCep());
            st.setLong(13, funcionario.getDepartamento().getId());
            st.setLong(14, funcionario.getId());
            st.executeUpdate();

        } catch (SQLException e) {
            throw new DbException(e.getMessage());
        } finally {
            Db.closeStatement(st);
        }
    }
}

package br.com.fatec.portalrh.application;

import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Dependente;
import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.entities.Projeto;
import br.com.fatec.portalrh.entities.valueObject.endereco.Cidade;
import br.com.fatec.portalrh.entities.valueObject.endereco.Endereco;
import br.com.fatec.portalrh.entities.valueObject.endereco.Estado;
import br.com.fatec.portalrh.entities.enums.Genero;
import br.com.fatec.portalrh.entities.valueObject.Cpf;
import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import br.com.fatec.portalrh.facade.SistemaRhFachada;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Program {

    public static void main(String[] args) throws Exception {
        SistemaRhUseCase sistemaRhUseCase = new SistemaRhFachada();
//        insertFuncionario(sistemaRhUseCase);
//        buscarTodosFuncionarios(sistemaRhUseCase);
//        deleteFuncionario(sistemaRhUseCase);
//        buscarPorId(sistemaRhUseCase);

//        listarDepartamentos(sistemaRhUseCase);

//        Funcionario trasFuncionario = buscarPorId(sistemaRhUseCase);
//        trasFuncionario.setNome("Paulo Martins");
//        sistemaRhUseCase.atualizarDadosFuncionario(trasFuncionario, 1L);
    }

    private static void listarDepartamentos(SistemaRhUseCase sistemaRhUseCase) {
        List<Departamento> lista = sistemaRhUseCase.listarDepartamento();
        lista.forEach(System.out::println);
    }

    private static void insertFuncionario(SistemaRhUseCase sistemaRhUseCase) throws Exception {
        String sData = "1998-12-31";
        String sData1 = "2021-05-30";
        Map<Long, Dependente> dependenteMap = new HashMap<>();
        Dependente dependente = null;
        dependenteMap.put(1L, dependente);

        Funcionario funcionario = new Funcionario(
                null,
                BigDecimal.valueOf(5000),
                "   Beatriz   ",
                new Cpf("13027972049"),
                new DataNascimento(sData),
                new Endereco("Rua Domingos",
                        "266",
                        "01234567",
                        "Mogi Atual",
                        Arrays.asList(new Estado("Sp",
                                new Cidade("Mogi das Cruzes")))),
                new Departamento(1L,
                        "Almoxarifado",
                        Arrays.asList(new Projeto(1L,
                                "Contagem",
                                "Estoque",
                                null)),Arrays.asList()),
                dependenteMap,
                Genero.MASCULINO,
                "PJ");

//        sistemaRhUseCase.salvarFuncionario(funcionario, regime);
    }

    private static void deleteFuncionario(SistemaRhUseCase sistemaRhUseCase) throws Exception {
        sistemaRhUseCase.excluirFuncionario(9L);
        System.out.println("Funcionario Deletado");
    }

    private static Funcionario buscarPorId(SistemaRhUseCase sistemaRhUseCase) throws Exception {
        Funcionario funcionario = sistemaRhUseCase.buscarFuncionarioPorId(1L);
        System.out.println(funcionario);

        return funcionario;
    }

    private static void buscarTodosFuncionarios(SistemaRhUseCase sistemaRhUseCase) throws Exception {
        List<Funcionario> lista = sistemaRhUseCase.buscarTodosFuncionarios();
        lista.forEach(System.out::println);
    }
}

package br.com.fatec.portalrh.application;

public class Program2 {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            System.out.println("Driver carregado com sucesso!");
        }
        catch (Exception ex) {
            System.out.println("Driver nao pode ser carregado!");
        }
    }
}

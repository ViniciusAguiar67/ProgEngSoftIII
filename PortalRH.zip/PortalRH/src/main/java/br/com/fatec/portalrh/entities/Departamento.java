package br.com.fatec.portalrh.entities;


import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;
import lombok.experimental.SuperBuilder;

import java.util.List;

@SuperBuilder
public class Departamento extends SistemaRh {

    private Nome nome = new NomeImp();
    private List<Projeto> projetos;
    private List<Funcionario> funcionarios;

    public Departamento(Long id, String nome) throws Exception {
        super(id);
        this.nome.validaNome(nome);
    }

    public Departamento(Long id) {
        super(id);
    }

    public Departamento(Long id, String nome, List<Projeto> projetos) throws Exception {
        super(id);
        this.nome.validaNome(nome);
        this.projetos = projetos;
    }

    public Departamento(Long id, String nome, List<Projeto> projetos, List<Funcionario> funcionarios) throws Exception {
        super(id);
        this.nome.validaNome(nome);
        this.projetos = projetos;
        this.funcionarios = funcionarios;
    }

    public Departamento() {
    }

    public void setNome(String nome) throws Exception {
        this.nome.validaNome(nome);
    }

    public String getNome() {
        return nome.exibirNome();
    }

    public List<Projeto> getProjetos() {
        return projetos;
    }

    public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    @Override
    public String toString() {
        return nome.exibirNome();
    }
}

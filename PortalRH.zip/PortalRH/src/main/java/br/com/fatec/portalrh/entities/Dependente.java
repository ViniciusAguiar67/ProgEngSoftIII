package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.enums.Genero;
import br.com.fatec.portalrh.entities.enums.Parentesco;
import br.com.fatec.portalrh.entities.valueObject.Cpf;
import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;

import lombok.experimental.SuperBuilder;

@SuperBuilder
public class Dependente extends SistemaRh {

    private Nome nome = new NomeImp();
    private Cpf cpf;
    private DataNascimento dataNascimento;
    private Genero genero;
    private Parentesco parentesco;
    private Funcionario funcionario;

    public Dependente() {

    }

    public Dependente(Long id,
                      String nome,
                      Cpf cpf,
                      DataNascimento dataNascimento,
                      Genero genero,
                      Parentesco parentesco,
                      Funcionario funcionario) throws Exception {
        super(id);
        this.nome.validaNome(nome);
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.genero = genero;
        this.parentesco = parentesco;
        this.funcionario = funcionario;
    }

    public String getNome() {
        return nome.exibirNome();
    }

    public Cpf getCpf() {
        return cpf;
    }

    public DataNascimento getDataNascimento() {
        return dataNascimento;
    }

    public Genero getGenero() {
        return genero;
    }

    public Parentesco getParentesco() {
        return parentesco;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setNome(String nome) throws Exception {
        this.nome.validaNome(nome);
        ;
    }

    public void setCpf(Cpf cpf) {
        this.cpf = cpf;
    }

    public void setDataNascimento(DataNascimento dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public void setParentesco(Parentesco parentesco) {
        this.parentesco = parentesco;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    @Override
    public String toString() {
        return "Nome: " + nome.exibirNome() +
                ", CPF: " + cpf.getCpf() +
                ", Data Nasc: " + dataNascimento +
                ", Genero: " + genero +
                ", Parentesco: " + parentesco;
    }
}

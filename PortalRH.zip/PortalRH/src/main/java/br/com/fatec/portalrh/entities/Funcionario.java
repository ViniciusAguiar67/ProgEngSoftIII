package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.endereco.Endereco;
import br.com.fatec.portalrh.entities.enums.Genero;
import br.com.fatec.portalrh.entities.valueObject.Cpf;
import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;
import lombok.Getter;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Map;

@Getter
@SuperBuilder
public class Funcionario extends SistemaRh {
    private static final Long serialVersionUID = 1L;

    private BigDecimal salario;
    private Nome nome = new NomeImp();
    private Cpf cpf;
    private DataNascimento dataNascimento;
    private Endereco endereco;
    private Departamento departamento;
    private Map<Long, Dependente> dependentes;
    private Genero genero;
    private String regime;

    public Funcionario() {
        super();
    }

    public Funcionario(Long id,
                       BigDecimal salario,
                       String nome,
                       Cpf cpf,
                       DataNascimento dataNascimento,
                       Endereco endereco,
                       Departamento departamento,
                       Map<Long, Dependente> dependentes,
                       Genero genero,
                       String regime
    ) throws Exception {
        super(id);
        this.salario = salario;
        this.nome.validaNome(nome);
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.endereco = endereco;
        this.departamento = departamento;
        this.dependentes = dependentes;
        this.genero = genero;
        this.regime = regime;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public void setNome(String nome) throws Exception {
        this.nome.validaNome(nome);
    }

    public void setCpf(Cpf cpf) {
        this.cpf = cpf;
    }

    public void setDataNascimento(DataNascimento dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public void setDependentes(Map<Long, Dependente> dependentes) {
        this.dependentes = dependentes;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public String getNome() {
        return nome.exibirNome();
    }

    public Cpf getCpf() {
        return cpf;
    }

    public DataNascimento getDataNascimento() {
        return dataNascimento;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public Map<Long, Dependente> getDependentes() {
        return dependentes;
    }

    public Genero getGenero() {
        return genero;
    }

    public String getRegime() {
        return regime;
    }

    public void setRegime(String regime) {
        this.regime = regime;
    }

    @Override
    public String toString() {
        return "\n\nFuncionario{" +
                "nome=" + nome.exibirNome() +
                ", cpf=" + cpf.getCpf() +
                ", dataNascimento=" + dataNascimento +
                ", salario=" + salario +
                ", regime=" + regime +
                ", endereco=" + endereco +
                ", departamento=" + departamento +
                ", dependentes=" + dependentes +
                ", genero=" + genero +
                '}';
    }
}

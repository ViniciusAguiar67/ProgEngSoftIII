package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;
import lombok.Getter;

@Getter
public class Projeto extends SistemaRh {

    private final Nome nome = new NomeImp();
    private String local;
    private Departamento departamento;

    public Projeto(Long id, String nome, String local) throws Exception {
        super(id);
        this.nome.validaNome(nome);
        validaLocal(local);
    }

    public Projeto(Long id, String nome, String local, Departamento departamento) throws Exception {
        super(id);
        this.nome.validaNome(nome);
        validaLocal(local);
        this.departamento = departamento;
    }

    public String getNome() {
        return nome.exibirNome();
    }

    public String getLocal() {
        return local;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    private void validaLocal(String local) throws Exception {
        if (local == null) {
            throw new Exception("localizacao vazia");
        }
        this.local = local;
    }

    @Override
    public String toString() {
        return nome.exibirNome() +
                ", Local:" + local;
    }
}

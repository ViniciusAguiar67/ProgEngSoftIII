package br.com.fatec.portalrh.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Setter
@Getter
@AllArgsConstructor
@SuperBuilder
public abstract class SistemaRh {

    private Long id;

    public SistemaRh() {
    }
}

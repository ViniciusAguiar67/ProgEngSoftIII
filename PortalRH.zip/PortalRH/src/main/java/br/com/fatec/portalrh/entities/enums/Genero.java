package br.com.fatec.portalrh.entities.enums;

public enum Genero {

    MASCULINO,
    FEMININO,
    OUTROS;
}

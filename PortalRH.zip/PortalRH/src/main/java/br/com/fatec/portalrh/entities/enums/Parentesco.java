package br.com.fatec.portalrh.entities.enums;

public enum Parentesco {

    CONJUGE,
    FILHO;
}

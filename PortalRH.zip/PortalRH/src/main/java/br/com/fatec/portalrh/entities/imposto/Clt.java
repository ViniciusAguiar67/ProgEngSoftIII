package br.com.fatec.portalrh.entities.imposto;

import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.ports.userInterface.Imposto;

import java.math.BigDecimal;

public class Clt implements Imposto {

    private static final String CLT_VAL = "0.1";

    @Override
    public BigDecimal calcular(Orcamento orcamento, Funcionario funcionario) {
        BigDecimal desconto = orcamento.getValor().multiply(new BigDecimal(CLT_VAL));
        return desconto.add(funcionario.getSalario());
    }
}

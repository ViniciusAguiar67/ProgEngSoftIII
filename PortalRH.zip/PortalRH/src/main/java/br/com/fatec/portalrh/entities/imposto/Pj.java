package br.com.fatec.portalrh.entities.imposto;

import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.ports.userInterface.Imposto;

import java.math.BigDecimal;

public class Pj implements Imposto {

    private static final String PJ_VAL = "0.6";

    @Override
    public BigDecimal calcular(Orcamento orcamento, Funcionario funcionario) {
        BigDecimal desconto = orcamento.getValor().multiply(new BigDecimal(PJ_VAL));
        return desconto.add(funcionario.getSalario());
    }
}

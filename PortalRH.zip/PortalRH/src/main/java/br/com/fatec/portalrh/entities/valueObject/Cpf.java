package br.com.fatec.portalrh.entities.valueObject;

import lombok.Getter;

import java.util.InputMismatchException;

@Getter
public final class Cpf {

    private final String cpf;

    public Cpf(final String cpf) throws Exception {
        this.cpf = validaCpf(cpf);
    }

    private String validaCpf(final String cpf) throws Exception {
        if (!Cpf.isCPF(cpf)) throw new Exception("CPF Invalido");
        return cpf;
    }

    private static boolean isCPF(final String cpf) throws Exception {
        if (retornaErroNumerosIguais(cpf))
            return false;
        return verificaDigitosCalculados(protegeCodigoDeEventuaisErros(cpf));
    }

    private static boolean protegeCodigoDeEventuaisErros(final String cpf) {
        char dig10, dig11;
        try {
            dig10 = calculaPrimeiroDigitoVerificador(cpf);
            dig11 = calculaSegundoDigitoVerificador(cpf);
            return verificaDigitosCalculados((dig10 == cpf.charAt(9)) && (dig11 == cpf.charAt(10)));
        } catch (InputMismatchException erro) {
            return false;
        }
    }

    private static boolean verificaDigitosCalculados(final boolean dig10) {
        return dig10;
    }

    private static char calculaSegundoDigitoVerificador(final String cpf) {
        char dig11;
        int sm, i, r, num, peso;
        sm = 0;
        peso = 11;
        for (i = 0; i < 10; i++) {
            num = (int) (cpf.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
        }
        r = 11 - (sm % 11);
        if ((r == 10) || (r == 11))
            dig11 = '0';
        else
            dig11 = (char) (r + 48);
        return dig11;
    }

    private static char calculaPrimeiroDigitoVerificador(final String cpf) {
        char dig10;
        int sm, r, num, peso;
        sm = 0;
        peso = 10;
        for (int i = 0; i < 9; i++) {
            num = (int) (cpf.charAt(i) - 48);
            sm = sm + (num * peso);
            peso = peso - 1;
        }
        r = 11 - (sm % 11);
        if ((r == 10) || (r == 11))
            dig10 = '0';
        else
            dig10 = (char) (r + 48);
        return dig10;
    }

    private static boolean retornaErroNumerosIguais(final String cpf) throws Exception {
        boolean numerosIguais = verificaDigitosCalculados(cpf.equals("00000000000") || cpf.equals("11111111111")
                || cpf.equals("22222222222") || cpf.equals("33333333333") || cpf.equals("44444444444") || cpf.equals("55555555555")
                || cpf.equals("66666666666") || cpf.equals("77777777777") || cpf.equals("88888888888")
                || cpf.equals("99999999999") || (cpf.length() != 11));
        if (numerosIguais) throw new Exception("Numeros Repetidos em Sequencia");
        return false;
    }

    public static String imprimeCPF(final String cpf) {
        return (cpf.substring(0, 3) + "." + cpf.substring(3, 6) + "." + cpf.substring(6, 9) + "-"
                + cpf.substring(9, 11));
    }
}

package br.com.fatec.portalrh.entities.valueObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public final class DataNascimento {

    private final Date dataNascimento;

    public DataNascimento(final String dataNascimento) throws Exception {
        this.dataNascimento = validaData(dataNascimento);
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    private Date validaData(final String data) throws Exception {
        Date data1 = null;
        if (validaStringData(data)) {
            if (validaDataMenorQueAtual(data)) {
                data1 = new SimpleDateFormat("yyyy-MM-dd").parse(data);
            } else {
                throw new Exception("Data Maior que a Data Atual!!!");
            }
        }
        return data1;
    }

    private boolean validaStringData(final String data) throws ParseException {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            sdf.setLenient(false);
            sdf.parse(data);
            return true;
        } catch (ParseException ex) {
            throw new ParseException("Formato de Data invalido", ex.getErrorOffset());
        }
    }

    public boolean validaDataMenorQueAtual(final String data) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dataVerificada = LocalDate.parse(data, dtf);
        LocalDate hoje = LocalDate.now();
        return dataVerificada.compareTo(hoje) <= 0;
    }

    @Override
    public String toString() {
        return "DataNascimento{" +
                "dataNascimento=" + dataNascimento +
                '}';
    }
}

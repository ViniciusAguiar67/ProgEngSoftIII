package br.com.fatec.portalrh.entities.valueObject;


import br.com.fatec.portalrh.ports.userInterface.Nome;

import java.util.ArrayList;
import java.util.List;

public final class NomeImp implements Nome {

    private String nome;

    public NomeImp() {
    }

    @Override
    public String exibirNome() {
        return nome;
    }

    @Override
    public void validaNome(final String nome) throws Exception {
        validaNomeNulo(nome);
        validaNomeVazio(nome);
        validaEntradaComNumero(nome);
        this.nome = formataPrimeiraLetra(nome);
    }

    private static String formataPrimeiraLetra(final String nome) {
        String apagaEspacosEmBranco = apagaEspacosEmBranco(nome);
        String[] nomeSplit = nomeSplit(apagaEspacosEmBranco);

        List<String> nomesFormatados = formataPrimeiraLetra(nomeSplit);

        StringBuilder nomeCompleto = concatenaString(nomesFormatados);

        return apagaEspacosEmBranco(nomeCompleto.toString());
    }

    private static StringBuilder concatenaString(List<String> nomesFormatados) {
        StringBuilder nomeCompleto = new StringBuilder();
        for (String nomeAlterado : nomesFormatados) {
            nomeCompleto.append(nomeAlterado).append(" ");
        }
        return nomeCompleto;
    }

    private static List<String> formataPrimeiraLetra(String[] nomeSplit) {
        List<String> nomesFormatados = new ArrayList<>();
        for (String nomeRecort : nomeSplit) {
            String alteraLetraMinuscula = nomeRecort.toLowerCase();
            char retornaPrimeiraLetra = alteraLetraMinuscula.charAt(0);
            String alteraLetraMaiuscula = String.valueOf(retornaPrimeiraLetra).toUpperCase();
            String nomeFormatado = alteraLetraMinuscula.substring(1, alteraLetraMinuscula.length());
            nomesFormatados.add(alteraLetraMaiuscula.concat(nomeFormatado));
        }
        return nomesFormatados;
    }

    public static String[] nomeSplit(String nome) {
        return nome.split(" ");
    }

    private static String apagaEspacosEmBranco(final String nome) {
        return nome.trim();
    }

    private void validaNomeVazio(final String nome) throws Exception {
        if (nome.isEmpty()) throw new Exception("Nome esta vazio");
    }

    private static void validaNomeNulo(final String nome) {
        if (null == nome) throw new NullPointerException("Nome esta nulo");
    }

    private void validaEntradaComNumero(final String nome) throws Exception {
        String retornaCaracteresInvalidos = nome.replaceAll("[ aA-zZà-úÀ-Ú]+", "");
        if (!retornaCaracteresInvalidos.isEmpty()) {
            throw new Exception("Você não pode inserir caracteres especiais");
        }
    }
}

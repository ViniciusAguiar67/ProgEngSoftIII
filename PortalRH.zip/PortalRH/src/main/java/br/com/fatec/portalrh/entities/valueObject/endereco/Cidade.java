package br.com.fatec.portalrh.entities.valueObject.endereco;


import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;

public final class Cidade {

    private Nome nome = new NomeImp();

    public Cidade(String nome) throws Exception {
        this.nome.validaNome(nome);
    }

    public void setNome(String nome) throws Exception {
        this.nome.validaNome(nome);
    }

    public String getNome() {
        return nome.exibirNome();
    }

    @Override
    public String toString() {
        return nome.exibirNome();
    }
}

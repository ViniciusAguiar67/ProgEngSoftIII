package br.com.fatec.portalrh.entities.valueObject.endereco;


import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;

import java.util.List;

public class Endereco {

    private String logradouro;
    private String numero;
    private String cep;
    private Nome bairro = new NomeImp();
    private List<Estado> estados;

    public Endereco(String logradouro, String numero, String cep, String bairro, List<Estado> estados) throws Exception {
        validaLogradouro(logradouro);
        validaNumero(numero);
        validaCep(cep);
        this.bairro.validaNome(bairro);
        this.estados = estados;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public void setBairro(Nome bairro) {
        this.bairro = bairro;
    }

    public void setEstados(List<Estado> estados) {
        this.estados = estados;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public String getCep() {
        return cep;
    }

    public String getBairro() {
        return bairro.exibirNome();
    }

    public List<Estado> getEstados() {
        return estados;
    }

    private void validaCep(final String cep) throws Exception {
        String formataCep = null;
        if (cep.length() == 8) {
            formataCep = String.format("%s-%s", cep.substring(0, 5), cep.substring(5, 8));
        } else {
            formataCep = cep;
        }
        assert formataCep != null;
        boolean valida = formataCep.replaceAll("[0-9]{5}-[0-9]{3}", "").isEmpty();
        if (!valida) {
            throw new Exception("CEP Invalido");
        }
        this.cep = formataCep;
    }

    private void validaLogradouro(final String logradouro) throws Exception {
        if (logradouro == null) {
            throw new Exception("Logradouro vazio");
        }
        this.logradouro = logradouro;
    }

    private void validaNumero(final String numero) throws Exception {
        if (numero == null) {
            throw new Exception("Numero do endereço está vazio");
        }
        this.numero = numero;
    }

    @Override
    public String toString() {
        return logradouro + ", " +
                numero + ", CEP:"
                + cep + ", "
                + bairro.exibirNome() +
                ", " + estados;
    }
}

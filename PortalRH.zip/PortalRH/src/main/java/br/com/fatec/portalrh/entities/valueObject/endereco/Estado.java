package br.com.fatec.portalrh.entities.valueObject.endereco;


import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;
import lombok.Setter;

@Setter
public class Estado {

    private Nome nome = new NomeImp();
    private Cidade cidade;

    public Estado(String nome, Cidade cidade) throws Exception {
        this.nome.validaNome(nome);
        this.cidade = cidade;
    }

    public String getNome() {
        return nome.exibirNome();
    }

    public Cidade getCidade() {
        return cidade;
    }

    @Override
    public String toString() {
        return nome.exibirNome() +
                ", " + cidade;
    }
}


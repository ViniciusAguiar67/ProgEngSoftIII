package br.com.fatec.portalrh.facade;

import br.com.fatec.portalrh.adapters.jdbc.impl.DaoFactory;
import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.ports.infrastructure.FuncionarioDao;
import br.com.fatec.portalrh.ports.userInterface.SistemaRhUseCase;
import br.com.fatec.portalrh.util.CalculadoraImposto;

import java.util.List;
import java.util.Optional;

public class SistemaRhFachada implements SistemaRhUseCase {

    private static final Long serialVersionUID = 1L;

    private final FuncionarioDao funcionarioDao = DaoFactory.createFuncionarioDao();

    @Override
    public void salvarFuncionario(Funcionario funcionario, String regime) {
        CalculadoraImposto.calcularSalario(funcionario, regime);

        funcionarioDao.insert(funcionario);
    }

    @Override
    public List<Funcionario> buscarTodosFuncionarios() throws Exception {
        return funcionarioDao.findAll();
    }

    @Override
    public Funcionario buscarFuncionarioPorId(Long id) throws Exception {
        Optional<Funcionario> funcionarioDaoById = funcionarioDao.findById(id);
        if (funcionarioDaoById == null) {
            throw new Exception("Nao foi possivel localizar o funcionario");
        }
        return funcionarioDaoById.get();
    }

    @Override
    public void excluirFuncionario(Long id) throws Exception {
        buscarFuncionarioPorId(id);
        funcionarioDao.delete(id);
    }

    @Override
    public void atualizarDadosFuncionario(Funcionario funcionario, Long id) throws Exception {
        Funcionario buscarFuncionarioPorId = buscarFuncionarioPorId(id);
        funcionario.setId(buscarFuncionarioPorId.getId());
        CalculadoraImposto.calcularSalario(funcionario, funcionario.getRegime());

        funcionarioDao.update(funcionario);
    }

    @Override
    public List<Departamento> listarDepartamento() {
        return funcionarioDao.findAllDepartamento();
    }


}

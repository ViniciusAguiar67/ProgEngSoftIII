package br.com.fatec.portalrh.ports.infrastructure;

import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Funcionario;

import java.util.List;
import java.util.Optional;

public interface FuncionarioDao {
    void insert(Funcionario funcionario );
    void update(Funcionario funcionario);
    Funcionario delete(Long id);
    Optional<Funcionario> findById(Long id) throws Exception;
    List<Funcionario> findAll() throws Exception;
    List<Departamento> findAllDepartamento();
}

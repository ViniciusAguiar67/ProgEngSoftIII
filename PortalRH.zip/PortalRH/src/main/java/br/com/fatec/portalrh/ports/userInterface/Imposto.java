package br.com.fatec.portalrh.ports.userInterface;

import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.entities.imposto.Orcamento;

import java.math.BigDecimal;

public interface Imposto {
    BigDecimal calcular(Orcamento orcamento, Funcionario funcionario);
}

package br.com.fatec.portalrh.ports.userInterface;

public interface Nome {

    String exibirNome();

    void validaNome(String nome) throws Exception;
}

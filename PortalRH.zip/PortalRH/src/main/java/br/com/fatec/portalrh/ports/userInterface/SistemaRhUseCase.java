package br.com.fatec.portalrh.ports.userInterface;

import br.com.fatec.portalrh.entities.Departamento;
import br.com.fatec.portalrh.entities.Funcionario;

import java.util.List;

public interface SistemaRhUseCase {
    public void salvarFuncionario(Funcionario funcionario, String regime);
    public List<Funcionario> buscarTodosFuncionarios() throws Exception;
    public Funcionario buscarFuncionarioPorId(Long id) throws Exception;
    public void excluirFuncionario(Long id) throws Exception;
    public void atualizarDadosFuncionario(Funcionario funcionario, Long id) throws Exception;
    public List<Departamento> listarDepartamento();
}

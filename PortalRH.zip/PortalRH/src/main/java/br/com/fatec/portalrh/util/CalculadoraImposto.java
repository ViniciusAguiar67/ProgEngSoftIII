package br.com.fatec.portalrh.util;

import br.com.fatec.portalrh.entities.Funcionario;
import br.com.fatec.portalrh.entities.imposto.Orcamento;
import br.com.fatec.portalrh.ports.userInterface.Imposto;

import java.math.BigDecimal;

public class CalculadoraImposto {

    private static final String PATH_CLASS_IMPOSTO = "br.com.fatec.portalrh.entities.imposto.";

    private static BigDecimal calcular(Orcamento orcamento, Funcionario funcionario, Imposto imposto) {
        return imposto.calcular(orcamento, funcionario);
    }

    public static final void calcularSalario(Funcionario funcionario, String regime) {
        Orcamento orcamento = new Orcamento(funcionario.getSalario());

        Imposto imposto = null;

        String nomeDaClasse = PATH_CLASS_IMPOSTO + regime;

        try {
            Class classe = Class.forName(nomeDaClasse);
            imposto = (Imposto) classe.newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
            throw new RuntimeException(e);
        }
        BigDecimal calcular = CalculadoraImposto.calcular(orcamento, funcionario, imposto);
        funcionario.setSalario(calcular);
    }
}

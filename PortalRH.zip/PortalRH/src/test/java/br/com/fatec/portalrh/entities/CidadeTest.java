package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.endereco.Cidade;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CidadeTest {

    @Test
    void verificarCidade() throws Exception {
        Cidade cidade = new Cidade("    são jose dos pinhais");

       // cidade.setNome("São Paulo");

        System.out.println("Nome da Cidade: " + cidade.getNome());
        assertEquals("São Jose Dos Pinhais", cidade.getNome());
    }

}
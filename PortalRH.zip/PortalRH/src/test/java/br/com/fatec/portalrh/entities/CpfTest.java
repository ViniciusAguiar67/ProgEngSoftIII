package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.Cpf;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CpfTest {

    @Test
    void validaCPF() throws Exception {
        Cpf cpf = new Cpf("71410443884");

        String retornaCpf = Cpf.imprimeCPF(cpf.getCpf());

        System.out.println("CPF: " + retornaCpf);
        assertEquals("714.104.438-84", retornaCpf);
    }

}
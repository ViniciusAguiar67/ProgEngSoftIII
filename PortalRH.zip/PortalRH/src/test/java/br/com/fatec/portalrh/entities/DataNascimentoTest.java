package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import org.junit.jupiter.api.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class DataNascimentoTest {
    @Test
    void validaDataNascimento() throws Exception {
        String sDate1 = "1998-12-10";
        DataNascimento dataNascimento = new DataNascimento(sDate1);

        String sData = "1998-12-10";
        Date sData2 = new SimpleDateFormat("yyyy-MM-dd").parse(sData);

        System.out.println("Data de Nascimento: " + dataNascimento.getDataNascimento());

        assertEquals(sData2, dataNascimento.getDataNascimento());
    }



}
package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.endereco.Endereco;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnderecoTest {

    @Test
    void retornaCep() throws Exception {
        Endereco endereco = new Endereco("Rua 11", "1127", "08717440", "Mogi", null);

        System.out.println("CEP: " + endereco.getCep());
        assertEquals("08717-440", endereco.getCep());
    }

    @Test
    void retornaLogradouro() throws Exception {
        Endereco endereco = new Endereco("Rua 11", "1127", "08717440", "Mogi", null);

        System.out.println("Logradouro: " + endereco.getLogradouro());
        assertEquals("Rua 11", endereco.getLogradouro());
    }

    @Test
    void retornaNumero() throws Exception {
        Endereco endereco = new Endereco("Rua 11", "1127", "08717440", "Mogi", null);

        System.out.println("Numero do Endereço: " + endereco.getNumero());
        assertEquals("1127", endereco.getNumero());
    }


}
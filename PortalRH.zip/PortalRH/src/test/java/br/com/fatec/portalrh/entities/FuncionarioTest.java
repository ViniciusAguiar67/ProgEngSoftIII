package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.endereco.Cidade;
import br.com.fatec.portalrh.entities.valueObject.endereco.Endereco;
import br.com.fatec.portalrh.entities.valueObject.endereco.Estado;
import br.com.fatec.portalrh.entities.enums.Genero;
import br.com.fatec.portalrh.entities.enums.Parentesco;
import br.com.fatec.portalrh.entities.valueObject.Cpf;
import br.com.fatec.portalrh.entities.valueObject.DataNascimento;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class FuncionarioTest {
/*
    @Test
    void getSalario() {
        Funcionario funcionario = Funcionario.builder()
                .nome(new Nome("Vinicius"))
                .salario(BigDecimal.ONE).build();

        assertEquals(BigDecimal.ONE, funcionario.getSalario());
        assertEquals("Vinicius", funcionario.getNome().getNome());
    }
    */

    @Test
    void validaFuncionario() throws Exception {
        String sData = "1998-12-31";
        String sData1 = "2021-12-31";
        Map<Long, Dependente> dependenteMap = new HashMap<>();
        Dependente dependente = new Dependente(1L,
                "Junior",
                new Cpf("69694582024"),
                new DataNascimento(sData1),
                Genero.MASCULINO,
                Parentesco.FILHO,
                null);
        dependenteMap.put(1L, dependente);

        Funcionario funcionario = new Funcionario(
                1L,
                BigDecimal.valueOf(5000),
                "Evandro",
                new Cpf("71410443884"),
                new DataNascimento(sData),
                new Endereco("Rua Domingos",
                        "266",
                        "01234567",
                        "Mogi Atual",
                        Arrays.asList(new Estado("Sp",
                                new Cidade("Mogi das Cruzes")))),
                new Departamento(1L,
                        "Rh",
                        Arrays.asList(new Projeto(1L,
                                "Teste",
                                "Fatec",
                                null)),Arrays.asList()),
                dependenteMap,
                Genero.MASCULINO,
                "PJ");

        Date sData2 = new SimpleDateFormat("yyyy-MM-dd").parse(sData);
        Date sData3 = new SimpleDateFormat("yyyy-MM-dd").parse(sData1);

        System.out.println(funcionario.getNome());
        System.out.println(funcionario.getCpf().getCpf());
        System.out.println(funcionario.getDataNascimento().getDataNascimento());
        System.out.println(funcionario.getEndereco().getLogradouro());
        System.out.println(funcionario.getEndereco().getNumero());
        System.out.println(funcionario.getEndereco().getCep());
        System.out.println(funcionario.getEndereco().getBairro());
        System.out.println(funcionario.getEndereco().getEstados().get(0).getNome());
        System.out.println(funcionario.getEndereco().getEstados().get(0).getCidade().getNome());
        System.out.println(funcionario.getDepartamento().getNome());
        System.out.println(funcionario.getDepartamento().getProjetos().get(0).getNome());
        System.out.println(funcionario.getDependentes().containsKey(1L));
//        System.out.println(funcionario.getDependentes().get(0).getCpf().getCpf());
//        System.out.println(funcionario.getDependentes().get(0).getDataNascimento().getDataNascimento());
//        System.out.println(funcionario.getDependentes().get(0).getGenero().name());
//        System.out.println(funcionario.getDependentes().get(0).getParentesco().name());
        System.out.println(funcionario.getGenero().name());

        assertEquals("Evandro", funcionario.getNome());
        assertEquals("71410443884", funcionario.getCpf().getCpf());
        assertEquals(sData2, funcionario.getDataNascimento().getDataNascimento());
        assertEquals("Rua Domingos", funcionario.getEndereco().getLogradouro());
        assertEquals("266", funcionario.getEndereco().getNumero());
        assertEquals("01234-567", funcionario.getEndereco().getCep());
        assertEquals("Mogi Atual", funcionario.getEndereco().getBairro());
        assertEquals("Sp", funcionario.getEndereco().getEstados().get(0).getNome());
        assertEquals("Mogi Das Cruzes", funcionario.getEndereco().getEstados().get(0).getCidade().getNome());
        assertEquals("Rh", funcionario.getDepartamento().getNome());
        assertEquals("Teste", funcionario.getDepartamento().getProjetos().get(0).getNome());
        assertEquals("Fatec",funcionario.getDepartamento().getProjetos().get(0).getLocal());
        assertEquals("Junior", funcionario.getDependentes().get(1L).getNome());
        assertEquals("69694582024", funcionario.getDependentes().get(1L).getCpf().getCpf());
        assertEquals(sData3, funcionario.getDependentes().get(1L).getDataNascimento().getDataNascimento());
        assertEquals(Genero.MASCULINO.name(), funcionario.getDependentes().get(1L).getGenero().name());
        assertEquals(Parentesco.FILHO.name(), funcionario.getDependentes().get(1L).getParentesco().name());
        assertEquals(Genero.MASCULINO.name(), funcionario.getGenero().name());
    }

}
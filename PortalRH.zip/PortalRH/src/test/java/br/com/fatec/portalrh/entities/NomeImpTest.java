package br.com.fatec.portalrh.entities;

import br.com.fatec.portalrh.entities.valueObject.NomeImp;
import br.com.fatec.portalrh.ports.userInterface.Nome;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NomeImpTest {

    @Test
    void validaNome() throws Exception {
        Nome nome = new NomeImp();
        nome.validaNome("   Mogi atual  ");

        System.out.println("Nome:" + nome.exibirNome());
        assertEquals("Mogi Atual", nome.exibirNome());
    }

}
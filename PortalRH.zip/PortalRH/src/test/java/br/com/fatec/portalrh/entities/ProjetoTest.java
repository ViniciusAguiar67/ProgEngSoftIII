package br.com.fatec.portalrh.entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProjetoTest {

    @Test
    void validaProjeto() throws Exception {
        Projeto projeto = new Projeto(1L,
                "mudanca",
                "apartamento", null);

        System.out.println("Nome Local: " + projeto.getLocal());
        assertEquals("apartamento", projeto.getLocal());
    }

}